Logo Facebook ?��
![deskripsi gambar](https://i.ibb.co/mR77crG/Screenshot-2022-07-17-11-27-29-805-com-termux.png)
Logo Instagram ?��
![deskripsi gambar](https://i.ibb.co/nzrNY3n/Screenshot-2022-07-19-15-07-30-575-com-termux.png)
Hasil Crack ?��
![deskripsi gambar](https://i.ibb.co/kh3JQSB/Screenshot-2022-07-19-23-45-48-956-com-termux.png)
Gambar hanya pemanis ?��?
## Cara Install
Download Aplikasi Termux Versi Terbaru?
[Termux Apk](https://f-droid.org/repo/com.termux_117.apk)??
```bash
$ cd
$ pkg update && pkg upgrade
$ pkg install python git
$ pkg install play-audio
$ pip install requests mechanize
$ pip install rich bs4
$ pip install stdiomask
$ pip install --upgrade pip
$ git clone https://github.com/RayhanZuck/BUcracking6
$ cd BUcracking6
$ python mom.py
```
## Cara Update
```php
$ cd BUcracking6
$ git pull
$ python mom.py
```
## MY SOCIAL MEDIA
[![](https://img.shields.io/badge/Github-black?logo=Github&logoColor=black&labelColor=white)](https://github.com/Al-Vino) [![](https://img.shields.io/badge/Twitter-blue?logo=Twitter&logoColor=White&labelColor=white)](https://mobile.twitter.com/AdjAlvino)
[![](https://img.shields.io/badge/Facebook-blue?logo=Facebook&logoColor=blue&labelColor=white)](https://www.facebook.com/Alvin0Xy.io)[![](https://img.shields.io/badge/Instagram-red?logo=Instagram&logoColor=red&labelColor=white)](https://www.instagram.com/mhff_xy) [![](https://img.shields.io/badge/Whatsapp-CHAT-red?logo=Whatsapp&logoColor=Brightgreen&labelColor=white)](https://wa.me/17154739342text=Halo+kak+alvino+ganteng)
## KASIH BINTANG WOY??????????????
![Typing SVG](https://readme-typing-svg.herokuapp.com?lines=Selamat+Bersenang-senang....!+)
